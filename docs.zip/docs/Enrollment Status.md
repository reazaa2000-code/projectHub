Pending Payment
Enrolled
Cancelled
Completed
Failed
Withdrawn